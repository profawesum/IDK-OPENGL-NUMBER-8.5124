#include "ParticleSystem.h"
#include "ShaderLoader.h"
#include "TextureLoader.h"
#include "Manager.h"

#include <iostream>

camera camParticle;
LoadTexture textureLoader;

using namespace glm;

ParticleSystem::ParticleSystem(glm::vec3 origin)
{

	glFrontFace(GL_CW);

	particleProgram = ShaderLoader::CreateProgram("Assets/shader/ParticleSystem.vs", "Assets/shader/ParticleSystem.fs", "Assets/shader/ParticleSystem.gs");

	nParticles = 4000;

	for (int i = 0; i < nParticles; i++) {

		vPosition.push_back(glm::vec3(0.0));
		Particle p = Particle(origin, glm::vec3(0.25f * cos(i * .0167f) + 0.25f * utils::randomFloat() - 0.125f, 2.0f + 0.25f * utils::randomFloat() - 0.125f, 0.25f * sin(i* .0167f) + 0.25f * utils::randomFloat() - 0.125f), utils::randomFloat() + 1.0f, 1.0f, i, camParticle);
		particles.push_back(p);

	}

	
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glGenVertexArrays(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vPosition.size(), &vPosition[0], GL_STATIC_DRAW);

	glGenTextures(0, &texture);
	texture = textureLoader.loadTexture("Assets/Textures/map.png");
	glBindTexture(GL_TEXTURE_2D, texture);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void ParticleSystem::render(float dt)
{
	for (int i = 0; i < nParticles; i++) {
		particles[i].update(dt);
		vPosition[i] = particles[i].getPosition();
	}

	mat4 viewMat = camParticle.getVPMatrix();
	vec3 vQuad1, vQuad2;

	glm::vec3 vView = camParticle.getCamLookDir();
	vView = glm::normalize(vView);

	vQuad1 = glm::cross(vView, glm::normalize(camParticle.getCamUpDir()));
	vQuad1 = glm::normalize(vQuad1);

	vQuad2 = glm::cross(vView, vQuad1);
	vQuad2 = glm::normalize(vQuad2);


	glUseProgram(particleProgram);

	glUniform3f(glGetUniformLocation(particleProgram, "vQuad1"), vQuad1.x, vQuad1.y, vQuad1.z);

	glUniform3f(glGetUniformLocation(particleProgram, "vQuad2"), vQuad2.x, vQuad2.y, vQuad2.z);

	glm::mat4 vp = camParticle.getVPMatrix();
	glUniformMatrix4fv(glGetUniformLocation(particleProgram, "vp"), 1, GL_FALSE, value_ptr(camParticle.getVPMatrix()));

	glActiveTexture(GL_TEXTURE0);
	glUniform1i(glGetUniformLocation(particleProgram, "Texture"), 0);
	glBindTexture(GL_TEXTURE_2D, texture);

	glEnable(GL_BLEND);
	glDepthMask(GL_FALSE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*vPosition.size(), &vPosition[0], GL_STATIC_DRAW);

	glBindVertexArray(vao);
	glDrawArrays(GL_POINTS, 0, nParticles);

	glBindVertexArray(0);

	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);

	//std::cout << "Ended rendering the particles" << std::endl;
}

//#include "ParticleSystem.h"
//#include "Particle.h"
//#include "ShaderLoader.h"
//#include "Camera.h"
//#include <random>
//#include "TextureLoader.h"
//
//
//LoadTexture loadTextureParticle;
//camera particleCam;
//
///*A random function used for the generation of particles.			*/
//static float randomFloat() {
//	return static_cast<float>(rand() / (double)RAND_MAX);
//}
//
//ParticleSystem::ParticleSystem(const glm::vec3 _Pos, glm::vec3 _Vel, const unsigned int _MaxParticles, const float _LifeTime)
//	: Pos(_Pos), nParticles(_MaxParticles) {
//
//}
//
//ParticleSystem::~ParticleSystem() {
//
//}
//
//
//void ParticleSystem::Init() {
//
//	program = ShaderLoader::CreateProgram("Assets/shader/ParticleSystem.vs", "Assets/shader/ParticleSystem.fs", "Assets/shader/ParticleSystem.gs");
//	//Generating all of the particles and pushing them to the particle vector
//	//Also pushes all the positions to the position vector too
//	for (unsigned short i = 0; i < nParticles; ++i) {
//		Particle n(
//			Pos,
//			glm::vec3(
//				1.25 * cos(i * .167) + 0.25f * randomFloat() - 0.125f,
//				5.0f + 0.25f * randomFloat() - 0.125f,
//				1.25 * sin(i* .167) + 0.25f * randomFloat() - 0.125f
//			),
//			5.0f,
//			i
//		);
//		particles.push_back(n);
//		vPosition.push_back(n.getPosition());
//	}
//
//	//Generating buffers
//	glGenVertexArrays(1, &vao);
//	glGenBuffers(1, &vbo);
//
//	glBindVertexArray(vao);
//	//Binding and setting buffer data
//	glBindBuffer(GL_ARRAY_BUFFER, vbo);
//	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vPosition.size(), vPosition.data(), GL_STATIC_DRAW);
//
//
//	//Enabling the positional floats
//	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
//	glEnableVertexAttribArray(0);
//
//	//Generating and binding the texture
//	//glGenTextures(1, &particleTexture);
//	glActiveTexture(GL_TEXTURE0);
//	particleTexture = loadTextureParticle.loadTexture("Assets / Textures / spaceShips_009.png");
//		glBindTexture(GL_TEXTURE_2D, particleTexture);
//
//
//
//	glBindTexture(GL_TEXTURE_2D, 0);
//	glBindVertexArray(0);
//	glBindBuffer(GL_ARRAY_BUFFER, 0);
//}
//
///*Process the particles in this system.								*/
//void ParticleSystem::Process(const float _deltaTime) {
//
//	//looping through all the particles in the particle vector, and updating the position vector.
//	for (unsigned int i = 0; i < nParticles; ++i) {
//		particles[i].update(_deltaTime);
//		vPosition[i] = particles[i].getPosition();
//		//particles[i].DistToCamera = glm::distance(CCamera::GetPos(), m_vParticleVect[i].GetPos());
//	}
//
//	//std::sort(particles.begin(), particles.end(), [&](Particle a, Particle b) { return a.DistToCamera > b.DistToCamera; });
//
//	//Rebinding the VBO with the new positional values
//	glBindBuffer(GL_ARRAY_BUFFER, vbo);
//	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vPosition.size(), vPosition.data(), GL_STATIC_DRAW);
//}
//
///*Rendering the particles in the system.							*/
//void ParticleSystem::Render() {
//	glUseProgram(program);
//
//	//Binding the array
//	glBindVertexArray(vao);
//
//	//Enable blending
//	glEnable(GL_BLEND);
//	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
//
//	//Setting and binding the correct texture
//	glActiveTexture(GL_TEXTURE0);
//	glBindTexture(GL_TEXTURE_2D, texture);
//
//	//Sending the texture to the GPU via uniform
//	glUniform1i(glGetUniformLocation(program, "tex"), 0);
//
//	glm::mat4 viewMat = particleCam.getVPMatrix();
//
//	glm::vec3 vQuad1, vQuad2;
//	glm::vec3 vView = particleCam.getCamTarget();
//
//	vView = glm::normalize(vView);
//
//	vQuad1 = glm::cross(vView, particleCam.getCamUpDir());
//
//	vQuad1 = glm::normalize(vQuad1);
//	vQuad2 = glm::cross(vView, vQuad1);
//	vQuad2 = glm::normalize(vQuad2);
//
//	glm::mat4 TranslationMatrix = glm::translate(glm::mat4(), Pos);
//	glm::mat4 ModelMatrix = TranslationMatrix * particleCam.getVPMatrix();
//
//
//	glUniform3f(glGetUniformLocation(program, "vQuad1"), vQuad1.x, vQuad1.y, vQuad1.z);
//	glUniform3f(glGetUniformLocation(program, "vQuad2"), vQuad2.x, vQuad2.y, vQuad2.z);
//
//
//	glUniformMatrix4fv(glGetUniformLocation(program, "vp"), 1, GL_FALSE, glm::value_ptr(particleCam.getVPMatrix()));
//
//	//glUniformMatrix4fv(glGetUniformLocation(m_uiShaderProg, "MVP"), 1, GL_FALSE, glm::value_ptr(ModelMatrix));
//	//glUniformMatrix4fv(glGetUniformLocation(m_uiShaderProg, "model"), 1, GL_FALSE, glm::value_ptr(ModelMatrix));
//	//glUniform3fv(glGetUniformLocation(m_uiShaderProg, "camPos"), 1, glm::value_ptr(Camera::GetPos()));
//	//Drawing the entity
//
//	//Setting back face culling
//	glCullFace(GL_BACK);
//	glFrontFace(GL_CW);
//	glEnable(GL_CULL_FACE);
//	glPointSize(1.0f);
//	glDrawArrays(GL_POINTS, 0, particles.size());// (GL_TRIANGLES, NumIndices, GL_UNSIGNED_INT, 0);
//
//	//Disabling backface culling
//	glDisable(GL_CULL_FACE);
//	glDisable(GL_BLEND);
//
//	//Clearing the vertex array
//	glBindVertexArray(0);
//}