#include "Particle.h"
#include "Manager.h"

#include <iostream>

Particle::Particle(vec3 origin, vec3 velocity, float elapsedTime, float speed, float id, camera cam)
{
	position = origin;
	this->velocity = velocity;
	this->elapsedTime = elapsedTime;
	this->speed = speed;
	this->id = id;
}

void Particle::update(float dt)
{
	velocity.y += -0.2 * dt;
	position += velocity;
	elapsedTime -= dt;
	//if it has reached the end of its time
	if (elapsedTime <= 0.0f) {
		position = origin;
		velocity = glm::vec3(0.25 * cos(id * dt) + 0.25f * utils::randomFloat() - 0.125f, 1.5f + 0.25f * utils::randomFloat() - 0.125f, 0.25 * sin(id* dt) + 0.25f * utils::randomFloat() - 0.125f);
		elapsedTime = utils::randomFloat() + 0.125;
	}
}

vec3 Particle::getPosition()
{
	return this->position;;
}

//
//#include "Particle.h"
//#include "ShaderLoader.h"
//#include <random>
//
//
///*A random function used for the generation of particles.			*/
//static float randomFloat() {
//	return static_cast<float>(rand() / (double)RAND_MAX);
//}
//
///*Constructs the particle with the input values. Should never fail.	*/
///*Has default values for _Vel and _Liftime, however initial _Origin	*/
///*must be provided.													*/
//Particle::Particle(const glm::vec3 _Origin, const glm::vec3 _Vel, const float _MaxLifetime, int _ID) :
//	position(_Origin),
//	velocity(_Vel),
//	time(randomFloat() * 4.0f),
//	elapsedTime(randomFloat()),
//	id(_ID)
//{
//	//DistToCamera = 0;
//}
//
//
///*Processes the particle position using Euler integration.			*/
///*Constructs a mat4 from the positional value, used in the rendering*/
///*process &	decrements the life value by deltaTime.					*/
//void Particle::update(const float _fdeltaTime) {
//	velocity.y += 0.25f * _fdeltaTime;
//	position += velocity * _fdeltaTime;
//	elapsedTime += _fdeltaTime;
//
//	if (elapsedTime >= time) {
//		position = origin;
//		velocity = glm::vec3(
//			-0.01f * cos(id * _fdeltaTime) * (20.0f * randomFloat()),
//			0.4f + 0.005 * randomFloat(),
//			-0.01f * sin(id * _fdeltaTime) *  (20.0f * randomFloat())
//		);
//		elapsedTime = randomFloat() * 10.0f;
//	}
//
//}
//
//glm::vec3 Particle::getPosition() { return position; }
