#pragma once

#include <iostream>
#include <vector>
#include <glew.h>
#include <glm.hpp>

#include "Particle.h"


class ParticleSystem {


public:

	ParticleSystem(glm::vec3 origin);
	~ParticleSystem();

	void render(float dt);

	std::vector<Particle> particles;
	std::vector<glm::vec3> vPosition;


private:

	GLuint vao, vbo, texture, particleProgram;
	float nParticles;

};
