#include "Manager.h"

//return the screen height
GLfloat utils::GetSCREEN_H()
{
	return (SCREEN_H);
}
//return the screen width
GLfloat utils::GetSCREEN_W()
{
	return (SCREEN_W);
}
//set the dimensions of the screen
void utils::SetScreenDimentions(int axis, int size)
{
	if (axis == 1)
	{
		SCREEN_W = static_cast<GLfloat>(size);
	}
	else if (axis == 2)
	{
		SCREEN_H = static_cast<GLfloat>(size);
	}
}

