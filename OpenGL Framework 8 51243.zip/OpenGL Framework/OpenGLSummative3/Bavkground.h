#pragma once
#include <glew.h>


class background {

public:

	void backgroundInit();
	void renderBackground();

};